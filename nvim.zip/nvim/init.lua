require("asswecan")
--vim.o.background = "dark"
vim.cmd([[ colorscheme matrix ]])


